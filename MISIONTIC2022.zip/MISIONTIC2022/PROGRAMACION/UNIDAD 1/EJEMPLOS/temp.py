# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

var1 = 1.20
print(var1)

var1=int(var1)
print(var1)

var1 = 120
var2 = 200
print(var1)
print(var2)

var1 = var2 = var3 = 200
print(var1)
print(var2)
print(var3)

var1 = var2 = var3 = 200
print(var1)
print(var2)
print(var3)
var2=350
print(var2)
print(var3)
var3=var2
print(var3)
print(var2)
print(var1)
a = 2
b = a+2
a = 3
b = a+2
print(a)
print(b)
#vaina enreda

